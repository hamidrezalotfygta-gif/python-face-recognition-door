"""لایهٔ دسترسی به دوربین و رله؛ GPIO به‌صورت اختیاری بارگذاری می‌شود."""
import time
import cv2
import config

class Camera:
    def __init__(self, source=config.CAMERA_SOURCE):
        self.source = source
        src = int(source) if source.isdigit() else source
        if config.CAMERA_BACKEND == "ffmpeg" and isinstance(src, str):
            self.capture = cv2.VideoCapture(src, cv2.CAP_FFMPEG)
        else:
            self.capture = cv2.VideoCapture(src)
        if not self.capture.isOpened():
            raise RuntimeError(f"بازکردن دوربین ناموفق بود: {source}")
        self.capture.set(cv2.CAP_PROP_FRAME_WIDTH, config.FRAME_WIDTH)
        self.capture.set(cv2.CAP_PROP_FRAME_HEIGHT, config.FRAME_HEIGHT)

    def read(self):
        ok, frame = self.capture.read()
        return frame if ok else None

    def release(self):
        if self.capture:
            self.capture.release()

class DoorRelay:
    """در حالت پیش‌فرض صرفاً پیام آزمایشی می‌دهد و هیچ قفلی را فعال نمی‌کند."""
    def __init__(self):
        self.enabled = config.RELAY_ENABLED
        self.gpio = None
        self.active_level = 1 if config.RELAY_ACTIVE_HIGH else 0
        self.inactive_level = 1 - self.active_level
        if self.enabled:
            try:
                import RPi.GPIO as GPIO
            except ImportError as exc:
                raise RuntimeError("برای رله، کتابخانه RPi.GPIO روی Raspberry Pi نصب شود") from exc
            self.gpio = GPIO
            GPIO.setmode(GPIO.BCM)
            GPIO.setup(config.RELAY_GPIO_PIN, GPIO.OUT, initial=self.inactive_level)

    def open_door(self, seconds=config.DOOR_OPEN_SECONDS):
        if not self.enabled:
            print("[DRY RUN] دسترسی مجاز؛ رله فعال نشد (RELAY_ENABLED=False).")
            return
        self.gpio.output(config.RELAY_GPIO_PIN, self.active_level)
        try:
            time.sleep(max(0.1, seconds))
        finally:
            self.gpio.output(config.RELAY_GPIO_PIN, self.inactive_level)

    def close(self):
        if self.gpio:
            self.gpio.output(config.RELAY_GPIO_PIN, self.inactive_level)
            self.gpio.cleanup(config.RELAY_GPIO_PIN)
