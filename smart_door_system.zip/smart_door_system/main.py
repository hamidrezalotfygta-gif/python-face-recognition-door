"""برنامهٔ اصلی تشخیص چهرهٔ مجاز و ثبت چهرهٔ ناشناس."""
from datetime import datetime
from pathlib import Path
import sys
import time
import cv2
import numpy as np
import config
from hardware import Camera, DoorRelay
from notifier import Notifier, make_logger

MODEL_PATH = config.BASE_DIR / "admin_faces" / "lbph_model.yml"
LABELS_PATH = config.BASE_DIR / "admin_faces" / "labels.txt"

class FaceAccess:
    def __init__(self, logger):
        if not hasattr(cv2, "face"):
            raise RuntimeError("ماژول cv2.face در دسترس نیست؛ opencv-contrib-python را نصب کنید")
        self.detector = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
        if self.detector.empty():
            raise RuntimeError("بارگذاری آشکارساز چهره ناموفق بود")
        self.recognizer = cv2.face.LBPHFaceRecognizer_create()
        self.names = {}
        self.logger = logger
        self._load_or_train()

    def _load_or_train(self):
        if MODEL_PATH.exists() and LABELS_PATH.exists():
            self.recognizer.read(str(MODEL_PATH))
            for line in LABELS_PATH.read_text(encoding="utf-8").splitlines():
                if "=" in line:
                    key, value = line.split("=", 1)
                    self.names[int(key)] = value
            if self.names:
                self.logger.info("مدل موجود بارگذاری شد (%d چهرهٔ مجاز)", len(self.names))
                return
        samples, ids = [], []
        for label, folder in enumerate(sorted(p for p in config.ADMIN_FACES_DIR.iterdir() if p.is_dir())):
            images = [p for p in folder.iterdir() if p.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp"}]
            used = 0
            for path in images:
                image = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
                if image is None:
                    self.logger.warning("تصویر قابل‌خواندن نیست: %s", path)
                    continue
                faces = self.detector.detectMultiScale(image, 1.1, 5, minSize=(60, 60))
                if len(faces):
                    x, y, w, h = max(faces, key=lambda r: r[2] * r[3])
                    samples.append(cv2.resize(image[y:y+h, x:x+w], (200, 200)))
                    ids.append(label)
                    used += 1
            if used:
                self.names[label] = folder.name
        if not samples:
            raise RuntimeError("هیچ نمونهٔ چهره‌ای پیدا نشد. برای هر فرد پوشه‌ای در admin_faces/ بسازید و تصاویر واضح اضافه کنید.")
        self.recognizer.train(samples, np.array(ids, dtype=np.int32))
        self.recognizer.write(str(MODEL_PATH))
        LABELS_PATH.write_text("".join(f"{k}={v}\n" for k, v in self.names.items()), encoding="utf-8")
        self.logger.info("مدل از %d نمونهٔ تصویری آموزش داده شد", len(samples))

    def process(self, frame):
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = self.detector.detectMultiScale(gray, config.FACE_SCALE_FACTOR,
                                               config.FACE_MIN_NEIGHBORS, minSize=(60, 60))
        results = []
        for x, y, w, h in faces:
            crop = cv2.resize(gray[y:y+h, x:x+w], (200, 200))
            label, distance = self.recognizer.predict(crop)
            name = self.names.get(label) if distance <= config.FACE_MATCH_THRESHOLD else None
            results.append((x, y, w, h, name, distance))
        return results

def main():
    logger = make_logger()
    notify = Notifier(logger)
    relay = DoorRelay()
    camera = None
    last_unknown = 0.0
    last_access = 0.0
    try:
        access = FaceAccess(logger)
        camera = Camera()
        notify.event("سامانهٔ هوشمند در فعال شد.")
        while True:
            frame = camera.read()
            if frame is None:
                logger.warning("فریم دریافت نشد؛ تلاش مجدد")
                time.sleep(1)
                continue
            for x, y, w, h, name, distance in access.process(frame):
                if name:
                    color, caption = (0, 180, 0), f"مجاز: {name}"
                    # برای جلوگیری از تحریک مکرر رله، هر ۸ ثانیه حداکثر یک‌بار
                    if time.monotonic() - last_access > 8:
                        notify.event(f"دسترسی مجاز: {name}")
                        relay.open_door()
                        last_access = time.monotonic()
                else:
                    color, caption = (0, 0, 255), "ناشناس"
                    now = time.monotonic()
                    if config.SAVE_UNKNOWN_IMAGES and now - last_unknown >= config.UNKNOWN_NOTIFY_COOLDOWN:
                        Path(config.INTRUDER_DIR).mkdir(parents=True, exist_ok=True)
                        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                        image_path = Path(config.INTRUDER_DIR) / f"unknown_{stamp}.jpg"
                        cv2.imwrite(str(image_path), frame)
                        notify.event("چهرهٔ ناشناس شناسایی شد.")
                        notify.photo(image_path, "هشدار: چهرهٔ ناشناس")
                        last_unknown = now
                if config.SHOW_WINDOW:
                    cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
                    cv2.putText(frame, caption, (x, max(25, y-10)), cv2.FONT_HERSHEY_SIMPLEX,
                                0.7, color, 2)
            if config.SHOW_WINDOW:
                cv2.imshow("Smart Door System - q to quit", frame)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break
    except KeyboardInterrupt:
        logger.info("توقف با درخواست کاربر")
    except Exception as exc:
        logger.exception("سامانه متوقف شد: %s", exc)
        return 1
    finally:
        if camera:
            camera.release()
        relay.close()
        cv2.destroyAllWindows()
    return 0

if __name__ == "__main__":
    sys.exit(main())
