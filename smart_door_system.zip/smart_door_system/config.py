"""تنظیمات سامانه؛ مقادیر را از متغیر محیطی می‌خواند."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

def _bool(name: str, default: bool) -> bool:
    return os.getenv(name, str(default)).strip().lower() in {"1", "true", "yes", "on"}

def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except ValueError as exc:
        raise ValueError(f"{name} باید عدد صحیح باشد") from exc

# LOCAL برای وب‌کم؛ RTSP برای دوربین شبکه. نمونه RTSP در README آمده است.
CAMERA_SOURCE = os.getenv("CAMERA_SOURCE", "0").strip()
CAMERA_BACKEND = os.getenv("CAMERA_BACKEND", "auto").strip().lower()
FRAME_WIDTH = _int("FRAME_WIDTH", 1280)
FRAME_HEIGHT = _int("FRAME_HEIGHT", 720)

# عملکرد قفل به‌طور پیش‌فرض غیرفعال است تا راه‌اندازی آزمایشی امن باشد.
RELAY_ENABLED = _bool("RELAY_ENABLED", False)
RELAY_GPIO_PIN = _int("RELAY_GPIO_PIN", 17)  # شماره‌گذاری BCM
RELAY_ACTIVE_HIGH = _bool("RELAY_ACTIVE_HIGH", True)
DOOR_OPEN_SECONDS = float(os.getenv("DOOR_OPEN_SECONDS", "5"))

FACE_MATCH_THRESHOLD = float(os.getenv("FACE_MATCH_THRESHOLD", "65"))
FACE_SCALE_FACTOR = float(os.getenv("FACE_SCALE_FACTOR", "1.1"))
FACE_MIN_NEIGHBORS = _int("FACE_MIN_NEIGHBORS", 5)
UNKNOWN_NOTIFY_COOLDOWN = _int("UNKNOWN_NOTIFY_COOLDOWN", 30)
SAVE_UNKNOWN_IMAGES = _bool("SAVE_UNKNOWN_IMAGES", True)
SHOW_WINDOW = _bool("SHOW_WINDOW", True)

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "").strip()
TELEGRAM_ENABLED = _bool("TELEGRAM_ENABLED", bool(TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID))
LOG_DIR = BASE_DIR / "logs"
INTRUDER_DIR = BASE_DIR / "intruders"
ADMIN_FACES_DIR = BASE_DIR / "admin_faces"
