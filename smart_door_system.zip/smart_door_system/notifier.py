"""ثبت رویدادها و اعلان اختیاری تلگرام."""
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
import requests
import config

def make_logger():
    Path(config.LOG_DIR).mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("smart_door")
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        handler = RotatingFileHandler(Path(config.LOG_DIR) / "smart_door.log", maxBytes=2_000_000,
                                      backupCount=5, encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
        logger.addHandler(handler)
        logger.addHandler(logging.StreamHandler())
    return logger

class Notifier:
    def __init__(self, logger=None):
        self.logger = logger or make_logger()

    def event(self, message: str):
        self.logger.info(message)
        if not config.TELEGRAM_ENABLED:
            return
        if not config.TELEGRAM_BOT_TOKEN or not config.TELEGRAM_CHAT_ID:
            self.logger.warning("تلگرام فعال است اما توکن یا شناسهٔ گفتگو تنظیم نشده است")
            return
        try:
            response = requests.post(
                f"https://api.telegram.org/bot{config.TELEGRAM_BOT_TOKEN}/sendMessage",
                data={"chat_id": config.TELEGRAM_CHAT_ID, "text": message}, timeout=10)
            response.raise_for_status()
        except requests.RequestException as exc:
            self.logger.error("ارسال اعلان تلگرام ناموفق بود: %s", exc)

    def photo(self, image_path: Path, caption: str):
        if not config.TELEGRAM_ENABLED:
            return
        try:
            with open(image_path, "rb") as image:
                response = requests.post(
                    f"https://api.telegram.org/bot{config.TELEGRAM_BOT_TOKEN}/sendPhoto",
                    data={"chat_id": config.TELEGRAM_CHAT_ID, "caption": caption},
                    files={"photo": image}, timeout=20)
            response.raise_for_status()
        except (OSError, requests.RequestException) as exc:
            self.logger.error("ارسال تصویر ناموفق بود: %s", exc)
